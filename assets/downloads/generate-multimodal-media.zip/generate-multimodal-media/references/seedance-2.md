# Seedance 2.0

Use `https://llm.mantai.me/v1/videos` to submit tasks and `https://llm.mantai.me/v1/videos/{task_id}` to poll. The API returns video task objects.

## Models

- `doubao-seedance-2.0`: quality/default model.
- `doubao-seedance-2.0-fast`: faster model for drafts and iteration.

The gateway also contains versioned aliases such as `doubao-seedance-2-0-260128` and `doubao-seedance-2-0-fast-260128`, but use the stable dotted names unless the operator asks otherwise.

## Request Shape

Top-level fields:

- `model`: required, one of the Seedance models above.
- `prompt`: required final text instruction. The API appends it as a text content item.
- `images`: optional array of image URLs or data URLs. The API converts these into `image_url` content items before the prompt.
- `seconds`: optional string duration. The API maps it to `duration`.
- `duration`: optional integer duration; use `seconds` for the standard video task call.
- `metadata`: optional object for model-specific parameters.

Fields to place in `metadata`:

- `content`: array of content items. Use for richer multimodal inputs:
  - text: `{"type":"text","text":"..."}`
  - image: `{"type":"image_url","image_url":{"url":"https://..."}}`
  - video: `{"type":"video_url","video_url":{"url":"https://..."}}`
  - audio: `{"type":"audio_url","audio_url":{"url":"https://..."}}`
- `resolution`: output resolution, commonly `720p`, `1080p`, or supported higher values.
- `ratio`: aspect ratio such as `16:9`, `9:16`, `1:1`, `4:3`, `3:4`, `21:9`.
- `duration`: integer seconds. Prefer top-level `seconds` unless metadata must exactly mirror the model-specific request.
- `frames`: optional frame count when the selected task type supports frame-level output.
- `seed`: optional integer for reproducibility.
- `camera_fixed`: optional boolean to reduce camera motion.
- `watermark`: optional boolean.
- `return_last_frame`: optional boolean.
- `generate_audio`: optional boolean for audio-video joint generation.
- `callback_url`: optional callback URL if the deployment supports webhooks.
- `service_tier`: optional service tier.
- `execution_expires_after`: optional integer expiry window.
- `draft`: optional boolean for draft mode where supported.
- `tools`: optional array such as `[{"type":"web_search"}]` if enabled.

## Input Roles

Label every media input before submitting:

- Still image reference: put URLs in top-level `images` for simple image-to-video.
- Rich image reference: use `metadata.content` with `image_url` items when combining with video/audio/text references.
- Video reference: use `metadata.content` with a `video_url` item and describe which motion, camera, or style should transfer.
- Audio reference: use `metadata.content` with an `audio_url` item and specify whether audio should guide rhythm, mood, dialogue, or sound design.

For reference-to-video, the final top-level `prompt` should state what to preserve from references and what to change. Avoid vague prompts such as "make it better"; specify subject motion, camera motion, duration, lighting, and audio expectations.

## Polling and Result

Submit returns:

```json
{
  "id": "task_xxx",
  "object": "video",
  "status": "queued",
  "created_at": 1234567890,
  "model": "doubao-seedance-2.0"
}
```

Poll until:

- `queued` or `in_progress`: continue polling.
- `completed`: read `metadata.url`.
- `failed`: read `error.message` and retry only after changing the prompt or parameters.

## Curl

```bash
TASK_ID=$(curl -sS "https://llm.mantai.me/v1/videos" \
  -H "Authorization: Bearer $MANTA_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "doubao-seedance-2.0",
    "prompt": "A 6 second cinematic shot of a small robot walking across a rainy neon street, slow tracking camera, realistic reflections.",
    "seconds": "6",
    "metadata": {
      "resolution": "1080p",
      "ratio": "16:9",
      "generate_audio": true
    }
  }' | jq -r '.id')

curl -sS "https://llm.mantai.me/v1/videos/$TASK_ID" \
  -H "Authorization: Bearer $MANTA_API_KEY" | jq
```

## Prompting Notes

Use concise, visual prompts with explicit duration, subject, motion, camera, lighting, style, and audio expectations. For image-to-video, explain which parts of the reference image must remain stable. For video-reference tasks, name the behavior to transfer and the behavior to avoid.

For multiple videos or aspect ratios, submit separate tasks. Keep each task's prompt focused on one output.
