# gpt-image-2

Use `https://llm.mantai.me/v1/images/generations` for generation and `https://llm.mantai.me/v1/images/edits` for edits. This API accepts standard image generation and edit fields for `gpt-image-2`.

## Generation Fields

Core fields:

- `model`: required, use `gpt-image-2`.
- `prompt`: required text prompt.
- `n`: optional number of images. Default is usually 1; ask before requesting multiple variants.
- `size`: optional. Use `auto`, `1024x1024`, `1536x1024`, `1024x1536`, or any valid custom resolution. Constraints: max edge <= 3840 px, both edges multiples of 16 px, long:short ratio <= 3:1, total pixels between 655360 and 8294400.
- `quality`: optional, one of `low`, `medium`, `high`, `auto`.
- `background`: optional, use `opaque` or `auto` for `gpt-image-2`; do not request `transparent`.
- `output_format`: optional, one of `png`, `jpeg`, `webp`.
- `output_compression`: optional integer 0-100 for JPEG/WebP.
- `moderation`: optional strictness field. Use only when the caller has a policy reason to tune moderation.
- `stream`: optional boolean for partial image streaming if the caller can consume events.
- `partial_images`: optional partial image count when streaming.
- `user`: optional end-user identifier.

Response:

- Prefer `data[0].b64_json`; decode it to the requested file.
- Do not rely on `url` for GPT Image models.
- `usage` or image token details may be present.

## Edit Fields

Use multipart for local files:

- `model`: `gpt-image-2`.
- `image[]` or `image`: one or more input images.
- `mask`: optional PNG mask for inpainting.
- `prompt`: edit instruction.
- `size`, `quality`, `background`, `output_format`, `output_compression`: same guidance as generation.
- `input_fidelity`: omit for `gpt-image-2`; input images are handled at high fidelity automatically.

## Edit Semantics

Treat local or attached images differently:

- If an image is the `edit target`, preserve identity, layout, perspective, and unchanged regions aggressively.
- If an image is a `reference image`, do not promise exact preservation; use it for style, composition, subject, or mood.
- If the user gives multiple images, state each role in the prompt or request metadata before calling.
- For text replacement or localization, include exact new text verbatim and require the original layout to remain stable.
- For compositing, describe placement, scale, lighting match, and occlusion.

## Transparent Output

`gpt-image-2` cannot produce native transparent backgrounds through `background=transparent`. Use one of these paths:

1. Default API path: generate the subject on a flat chroma-key background such as `#00ff00`, then remove the key locally with the host's image-processing tools.
2. Opaque asset path: use `background: "opaque"` or omit `background`.
3. Native transparency path: ask the user before switching away from this model path.

For chroma-key prompts, require one uniform background color with no shadows, gradients, texture, reflections, floor plane, or contact shadow. Choose a key color that is absent from the subject.

## Curl

```bash
curl -sS "https://llm.mantai.me/v1/images/generations" \
  -H "Authorization: Bearer $MANTA_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "gpt-image-2",
    "prompt": "A clean product render of a brushed steel desk lamp on a white studio background",
    "size": "1024x1024",
    "quality": "medium",
    "output_format": "png"
  }' | jq -r '.data[0].b64_json' | base64 --decode > image.png
```

## Prompting Notes

Specify subject, composition, material, lighting, camera/framing, style, and constraints. For product or UI assets, include background, aspect ratio, exact labels, and what must not change. For edits, describe what to preserve before describing the change.

For batches, use separate prompts for separate assets. Use `n` only when asking for variants of one prompt.
