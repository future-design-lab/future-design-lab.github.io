#!/usr/bin/env python3
import argparse
import base64
import json
import os
import sys
import time
import urllib.error
import urllib.request


BASE_URL = "https://llm.mantai.me/v1"


def env(name, default=None):
    value = os.environ.get(name, default)
    if value is None or value == "":
        raise SystemExit(f"Missing required environment variable: {name}")
    return value


def request_json(method, path, payload=None):
    api_key = env("MANTA_API_KEY")
    body = None if payload is None else json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        BASE_URL + path,
        data=body,
        method=method,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise SystemExit(f"HTTP {exc.code}: {detail}") from exc


def image(args):
    payload = {
        "model": args.model,
        "prompt": args.prompt,
        "size": args.size,
        "quality": args.quality,
        "output_format": args.format,
    }
    if args.background:
        payload["background"] = args.background
    if args.compression is not None:
        payload["output_compression"] = args.compression
    response = request_json("POST", "/images/generations", payload)
    data = response.get("data") or []
    if not data or not data[0].get("b64_json"):
        print(json.dumps(response, ensure_ascii=False, indent=2))
        raise SystemExit("Response did not contain data[0].b64_json")
    with open(args.out, "wb") as fh:
        fh.write(base64.b64decode(data[0]["b64_json"]))
    print(args.out)


def video(args):
    metadata = {}
    if args.resolution:
        metadata["resolution"] = args.resolution
    if args.ratio:
        metadata["ratio"] = args.ratio
    if args.seed is not None:
        metadata["seed"] = args.seed
    if args.generate_audio is not None:
        metadata["generate_audio"] = args.generate_audio
    if args.metadata:
        metadata.update(json.loads(args.metadata))
    payload = {
        "model": args.model,
        "prompt": args.prompt,
        "seconds": str(args.seconds),
    }
    if args.image:
        payload["images"] = args.image
    if metadata:
        payload["metadata"] = metadata
    response = request_json("POST", "/videos", payload)
    print(json.dumps(response, ensure_ascii=False, indent=2))
    if args.wait:
        task_id = response.get("id") or response.get("task_id")
        if task_id:
            poll(argparse.Namespace(task_id=task_id, interval=args.interval, max_wait=args.max_wait))


def poll(args):
    deadline = time.time() + args.max_wait
    last = None
    while time.time() <= deadline:
        last = request_json("GET", f"/videos/{args.task_id}")
        status = last.get("status")
        print(json.dumps(last, ensure_ascii=False, indent=2))
        if status in {"completed", "failed"}:
            return
        time.sleep(args.interval)
    raise SystemExit(f"Timed out waiting for {args.task_id}; last status: {last}")


def main():
    parser = argparse.ArgumentParser(description="Generate images and videos through https://llm.mantai.me/v1.")
    sub = parser.add_subparsers(required=True)

    p_img = sub.add_parser("image")
    p_img.add_argument("--prompt", required=True)
    p_img.add_argument("--out", default="image.png")
    p_img.add_argument("--model", default="gpt-image-2")
    p_img.add_argument("--size", default="1024x1024")
    p_img.add_argument("--quality", default="medium")
    p_img.add_argument("--format", default="png", choices=["png", "jpeg", "webp"])
    p_img.add_argument("--background", choices=["opaque", "auto"])
    p_img.add_argument("--compression", type=int)
    p_img.set_defaults(func=image)

    p_video = sub.add_parser("video")
    p_video.add_argument("--prompt", required=True)
    p_video.add_argument("--model", default="doubao-seedance-2.0")
    p_video.add_argument("--seconds", default=6)
    p_video.add_argument("--image", action="append", help="Reference image URL or data URL. Can be repeated.")
    p_video.add_argument("--resolution", default="1080p")
    p_video.add_argument("--ratio", default="16:9")
    p_video.add_argument("--seed", type=int)
    audio = p_video.add_mutually_exclusive_group()
    audio.add_argument("--generate-audio", action="store_true", dest="generate_audio")
    audio.add_argument("--no-generate-audio", action="store_false", dest="generate_audio")
    p_video.set_defaults(generate_audio=None)
    p_video.add_argument("--metadata", help="Additional JSON object merged into metadata.")
    p_video.add_argument("--wait", action="store_true")
    p_video.add_argument("--interval", type=int, default=10)
    p_video.add_argument("--max-wait", type=int, default=600)
    p_video.set_defaults(func=video)

    p_poll = sub.add_parser("poll")
    p_poll.add_argument("task_id")
    p_poll.add_argument("--interval", type=int, default=10)
    p_poll.add_argument("--max-wait", type=int, default=600)
    p_poll.set_defaults(func=poll)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
